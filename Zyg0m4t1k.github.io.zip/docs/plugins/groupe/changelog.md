---
title: Changelog
sidebar_label: Changelog
sidebar_position: 99
---
# 14.02.2026

- Compatibilité jeedom 4.5
- Corrections des bugs et optimisation du code

  # 13.02.2021

- Vue mobile

  # 13.02.2021

- Changement de répertoire des images suite à maj du core et effacement des fichiers non utilisés (en cas d'échec lors de la mise à jour , aller dans la configuration générale du plugin);
- Envoie de message dans le centre de messages quand une commande n'est plus reconnue
- Possibilité de choisir une image ou une icône pour le widget
- Activation des listeners en cas d'activation/désactivation du plugin

  # 28.04.2020

- icône
- Possibilité de paramétrer quand le widget se met à jour
- Possibilité de sélectionner une image au lieu d'une icône

  # 08.12.2019

- Fixe la possibilité de changer le nom des commandes.

# XX-11-2019

- Correction de l'affichage du nom/objet v3/v4
- Bouton dupliquer pour chaque équipement
- Suppression de la roue crantée
- Amélioration de la modale (mise en forme,ajout de la date de la dernière communication triée par date descendante)
- Confirmation compatibilité v4/buster

# XX-08-2019

- Fix widgets
- Fix php 7.3
- change fa to fas

  # 15.02.2019

* Ajout de la configuration générale du plugin dans la partie desktop
* Commande All On/All off quelque soit l'état

  # 12.07.2018

* Icone desktop

# 2-02-2018

- Bug fixes

# 26-01-2018

- Changements d'actions sur le widget
- Mise à jour de la documentation

  # 24.12.2017

- Ajout des commandes All ON et All OFF
- Possibilité de trier l'ordre des commandes dans la configuration de l'équipement
- Correction du bug d'affichage lors de la suppression d'un équipement
- Possibilité de choisir le nom des commandes dans la modale
- Autorisation de tous les utilisateurs
- Correction du bug concernant la création des commandes
- Correction des commandes inversées dans la modale
- Icone

  # 26.04.2017

- Ajout des commandes en cliquant sur l'icône du widget.

  # 10.04.2017

- Ajout d'une commande pour connaître le déclencheur d'un changement d'état

  # 27.03.2017

- Ajout de commandes d'état. Préparation pour l'ajout de commande Action. Nettoyage du code.Refonte graphique de l'équipement. Maj doc

  # 20.03.2017

- Correction pour le mode personnalisé.Passage en stable.Possibilité d'inverser les commandes

  # 19.03.2017

- Mise à disposition du plugin sur le market en bétâ
