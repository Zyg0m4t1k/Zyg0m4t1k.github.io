---
title: Changelog
sidebar_label: Changelog
sidebar_position: 99
---
Historique des versions du plugin. Les entrées sont listées de la plus récente à la plus ancienne.

### Version Beta 20.02.2026

- Ajout de la double authentification (2FA) iCloud
- Nettoyage et sécurisation du code PHP/Python
- Refonte de la synchronisation des appareils iCloud
- Amélioration de la création et mise à jour des équipements
- Compatibilité Jeedom 4.4+ / PHP 8.2+ / Debian Trixie
- Corrections de bugs et stabilité générale

## 10-10-2020

- v4 compatible (info.json)

## 01-09-2019

- Hide password

## XX-08-2019

- Fix widgets
- Fix php 7.3
- change fa to fas

## 4.03.2019
* Date apparaissant sur le widgetLeaflet correspond à la date de récupération de la localisation
* Statut de la batterie ne se met pas à jour si status "203" (renvoit 0 systématiquement)

## 2.03.209

* Possibilité de déterminer un délai avant de mettre le device en hors ligne (1 heure par défaut)
* Suppression des logs d'erreur...

## *.12.2018

* Force l'update en cas de localisation erronée
* Corrections de bug (retour getCron)

## 29.07.2018

* Possibilité de définir le Map Leaflet en paramètre pour la commande Localisation sinon assigner un widget spécifique si besoin
* Widget

## 12-20.07.2018

* Panel desktop (Devices)
* Widget devices (Desktop , mobile)
* Ajout d'un paramètre pour optimiser la localisation.

## 30.05.2018

* Possibilité de mettre à jour la commande "Localisation" d'un autre plugin (Geoloc,Geotrav).
* Ajout de commandes pour les devices
* Optimisation du recueil des informations. Les infos sont mises à jour seulement si la date de mise à jour a changé.
* Docs

## 08.03.2018

* Ajout de plusieurs commandes (Voir doc)

## 24.02.2018

* Ajout de commandes pour changer le cron (voir doc)
* Suppression des crons

## 02-01-2018

- Popup supprimée

## 29-01-2018

- Correction pour l'aide au cron
- Au revoir ancienne doc

## 28-01-2018

- Mise à niveau avec la nouvelle documentation

## **-12-2017

-   Doc

-  Gestion du multicompte

## 18.12.2017

- Ajout de la commande "batterie".
- Correction de la commande refresh
- Mise à jour de la documentation

## 8.12.2017

-  Mise à disposition de la bétâ sur le market
