export const pluginsNav = [
  { label: "iOSCloud", to: "/plugins/ioscloud" },
  { label: "SwitchBot", to: "/plugins/switchbot" },
  { label: "ICS", to: "/plugins/ics" },
];