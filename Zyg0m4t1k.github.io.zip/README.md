# Zyg0m4t1k.github.io

Documentation.

Site Docusaurus (GitHub Pages) pour centraliser la documentation et les fiches vitrines de mes plugins Jeedom.

## Développement local

```bash
npm ci
npm start
