18.01.2021
===

- Fix la création des commandes...

17.12.20
===

- Etat des curtains (Via jeedom seulement)

06.12.20
===

- Ajout de la prise en charge des curtains

21.11.20
===

- Gestion des mots de passe pour les actionneurs

10.10.20
===

- Fix récupération des données des sondes , récupération du firmware et de la batterie

27.03.2020
===

- En cas d'antennes , il faut mettre à jour les fichiers
- Icônes
- Documentation
- Health
- Prérequis
- Changelog
- Fix scan

27.03.2020
===

- En cas d'antennes , il faut mettre à jour les fichiers
- Fix log
- Fix cronDaily

11.03.2020
===

- Mise à disposition du plugin sur le market (stable)
