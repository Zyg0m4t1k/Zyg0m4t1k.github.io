import React from 'react';
import PluginsLayout from '../../components/PluginsLayout';

export default function IcsPlugin() {
  return (
    <PluginsLayout>
      <h1>Groupe</h1>
      <p>Cette page arrive bientôt.</p>
    </PluginsLayout>
  );
}